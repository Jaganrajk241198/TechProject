package com.projectincedoplayapp1.incedoplayapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Incedoplayapp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
