package com.projectincedoplayapp1.incedoplayapp1.controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
//import com.projectincedoplay.reglog.*;

@RestController
public class Controller extends HttpServlet {

	@PostMapping("/saveUser")
	public String saveuser(@RequestBody UserPojo user, HttpServletRequest httpServletRequest) {
		System.out.println("1---------");
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<UserPojo> entity = new HttpEntity<UserPojo>(user);
		String url = "http://localhost:8080/" + user.getEmail();
		String body = restTemplate.exchange(url, HttpMethod.GET, entity, String.class).getBody();
		System.out.println("ABCc");
		UserPojo data = (UserPojo) httpServletRequest.getSession().getAttribute("id");
		System.out.println("2---------");
		if (user != null) {
			if (body != null) {
				if (data != null) {
					if (user.getEmail().equals(data.getEmail())) {
						return "You are already loggedin!";
					} else {
						httpServletRequest.getSession().removeAttribute("id");
						httpServletRequest.getSession().setAttribute("id", data);
						return "Successfully Logged in";
					}
				} else {
				httpServletRequest.getSession().setAttribute("id", data);					return "Successfully loggedin!";
				}
			} else {
				return "Invalid credentials!";
			}

			//System.out.println("Hi hello");
		//	return "Login Successful";
		} else {
			return "Login Failed";
		}

	}

}
