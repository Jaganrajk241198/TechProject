package com.projectincedoplayapp1.incedoplayapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Incedoplayapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Incedoplayapp1Application.class, args);
	}

}
