package com.projectincedoplay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class IncedoplayApplication {

	public static void main(String[] args) {
		SpringApplication.run(IncedoplayApplication.class, args);
	}

}
